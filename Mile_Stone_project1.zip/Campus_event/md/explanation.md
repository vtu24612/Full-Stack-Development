# Node.js Backend Explanation - Campus Event Portal

## 📁 Project Structure

```
server/
├── server.js                   # Main entry point
├── config/                     # Configuration
│   └── database.js            # MySQL connection pool
├── routes/                     # API endpoints
│   ├── auth.js               # Authentication routes
│   ├── events.js             # Event management routes
│   ├── categories.js         # Category routes
│   └── registrations.js      # Registration routes
├── package.json               # Dependencies
└── .env                       # Environment variables
```

---

## 🚀 Main Server File

### **server.js**
```javascript
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 8080;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/registrations', registrationRoutes);

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
```

**Purpose:** Entry point of the Node.js application
- `express()` - Creates Express application
- `cors()` - Enables cross-origin requests from frontend
- `bodyParser.json()` - Parses JSON request bodies
- `app.use()` - Mounts route handlers
- `app.listen()` - Starts HTTP server on port 8080

---

## ⚙️ Database Configuration

### **config/database.js**
```javascript
const mysql = require('mysql2');

const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME || 'campus_events_db',
    waitForConnections: true,
    connectionLimit: 10
});

const promisePool = pool.promise();
module.exports = promisePool;
```

**Purpose:** MySQL database connection management
- `createPool()` - Creates connection pool for efficiency
- `connectionLimit: 10` - Max 10 concurrent connections
- `promise()` - Enables async/await syntax
- Environment variables from `.env` file
- Connection pooling prevents creating new connections for each query

---

## 🌐 Authentication Routes

### **routes/auth.js**

#### Register New User
```javascript
router.post('/register', async (req, res) => {
    try {
        const { fullName, email, studentId, password, role } = req.body;

        // Check if email exists
        const [existingUsers] = await db.query(
            'SELECT * FROM users WHERE email = ?',
            [email]
        );

        if (existingUsers.length > 0) {
            return res.status(400).json({ error: 'Email already registered' });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Insert user
        const [result] = await db.query(
            'INSERT INTO users (full_name, email, student_id, password_hash, role) VALUES (?, ?, ?, ?, ?)',
            [fullName, email, studentId, hashedPassword, role || 'student']
        );

        res.status(201).json({
            userId: result.insertId,
            fullName,
            email,
            role: role || 'student',
            message: 'Registration successful'
        });
    } catch (error) {
        console.error('Register error:', error);
        res.status(500).json({ error: 'Registration failed' });
    }
});
```

**Key Concepts:**
- `async/await` - Handles asynchronous database operations
- `bcrypt.hash(password, 10)` - Hashes password with 10 salt rounds
- `?` placeholders - Prevents SQL injection
- `result.insertId` - Gets auto-generated user ID
- `res.status(201)` - HTTP 201 Created status

#### Login User
```javascript
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Find user
        const [users] = await db.query(
            'SELECT * FROM users WHERE email = ?',
            [email]
        );

        if (users.length === 0) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const user = users[0];

        // Verify password
        const isValid = await bcrypt.compare(password, user.password_hash);

        if (!isValid) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        res.json({
            userId: user.user_id,
            fullName: user.full_name,
            email: user.email,
            role: user.role,
            message: 'Login successful'
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Login failed' });
    }
});
```

**Key Concepts:**
- `bcrypt.compare()` - Verifies password against hash
- `res.status(401)` - HTTP 401 Unauthorized
- Destructuring: `const { email, password } = req.body`

---

## 📅 Event Routes

### **routes/events.js**

#### Get All Events
```javascript
router.get('/', async (req, res) => {
    try {
        const [events] = await db.query(`
            SELECT e.*, c.category_name, u.full_name as creator_name
            FROM events e
            LEFT JOIN categories c ON e.category_id = c.category_id
            LEFT JOIN users u ON e.created_by = u.user_id
            ORDER BY e.event_date DESC
        `);
        res.json(events);
    } catch (error) {
        console.error('Get events error:', error);
        res.status(500).json({ error: 'Failed to fetch events' });
    }
});
```

**Key Concepts:**
- `LEFT JOIN` - Combines data from multiple tables
- `ORDER BY` - Sorts results by date
- SQL queries return arrays: `[rows, fields]`
- Destructuring gets just the rows

#### Get Upcoming Events
```javascript
router.get('/upcoming', async (req, res) => {
    try {
        const [events] = await db.query(`
            SELECT e.*, c.category_name, u.full_name as creator_name
            FROM events e
            LEFT JOIN categories c ON e.category_id = c.category_id
            LEFT JOIN users u ON e.created_by = u.user_id
            WHERE e.event_date >= NOW()
            ORDER BY e.event_date ASC
        `);
        res.json(events);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch upcoming events' });
    }
});
```

**Key Concepts:**
- `NOW()` - MySQL function for current timestamp
- `WHERE` clause filters future events

#### Create New Event
```javascript
router.post('/', async (req, res) => {
    try {
        const { title, description, eventDate, location, categoryId, capacity, bannerImg, createdBy } = req.body;

        const [result] = await db.query(
            'INSERT INTO events (title, description, event_date, location, category_id, capacity, available_seats, banner_img, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [title, description, eventDate, location, categoryId, capacity, capacity, bannerImg, createdBy]
        );

        const [newEvent] = await db.query('SELECT * FROM events WHERE event_id = ?', [result.insertId]);
        res.status(201).json(newEvent[0]);
    } catch (error) {
        console.error('Create event error:', error);
        res.status(500).json({ error: 'Failed to create event' });
    }
});
```

**Key Concepts:**
- `result.insertId` - Gets ID of newly created event
- `available_seats` initialized to `capacity`
- Second query fetches complete event data

---

## 🎫 Registration Routes

### **routes/registrations.js**

#### Register for Event (with Transaction)
```javascript
router.post('/', async (req, res) => {
    const connection = await db.getConnection();
    
    try {
        await connection.beginTransaction();

        const { userId, eventId } = req.body;

        // Check if already registered
        const [existing] = await connection.query(
            'SELECT * FROM registrations WHERE user_id = ? AND event_id = ?',
            [userId, eventId]
        );

        if (existing.length > 0) {
            await connection.rollback();
            return res.status(400).json({ error: 'Already registered' });
        }

        // Check available seats
        const [events] = await connection.query(
            'SELECT available_seats FROM events WHERE event_id = ?',
            [eventId]
        );

        if (events[0].available_seats <= 0) {
            await connection.rollback();
            return res.status(400).json({ error: 'No seats available' });
        }

        // Create registration
        await connection.query(
            'INSERT INTO registrations (user_id, event_id, status) VALUES (?, ?, ?)',
            [userId, eventId, 'confirmed']
        );

        // Decrement available seats
        await connection.query(
            'UPDATE events SET available_seats = available_seats - 1 WHERE event_id = ?',
            [eventId]
        );

        await connection.commit();

        res.status(201).json({ message: 'Registration successful' });
    } catch (error) {
        await connection.rollback();
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Registration failed' });
    } finally {
        connection.release();
    }
});
```

**Key Concepts:**
- `getConnection()` - Gets dedicated connection for transaction
- `beginTransaction()` - Starts database transaction
- `commit()` - Saves all changes if successful
- `rollback()` - Reverts all changes if error occurs
- `finally` - Always releases connection back to pool
- Ensures atomicity: both registration and seat update succeed or both fail

#### Cancel Registration
```javascript
router.delete('/:id', async (req, res) => {
    const connection = await db.getConnection();
    
    try {
        await connection.beginTransaction();

        // Get registration details
        const [registrations] = await connection.query(
            'SELECT * FROM registrations WHERE registration_id = ?',
            [req.params.id]
        );

        if (registrations.length === 0) {
            await connection.rollback();
            return res.status(404).json({ error: 'Registration not found' });
        }

        const registration = registrations[0];

        // Delete registration
        await connection.query('DELETE FROM registrations WHERE registration_id = ?', [req.params.id]);

        // Increment available seats
        await connection.query(
            'UPDATE events SET available_seats = available_seats + 1 WHERE event_id = ?',
            [registration.event_id]
        );

        await connection.commit();

        res.json({ message: 'Registration cancelled successfully' });
    } catch (error) {
        await connection.rollback();
        console.error('Cancel registration error:', error);
        res.status(500).json({ error: 'Failed to cancel registration' });
    } finally {
        connection.release();
    }
});
```

**Key Concepts:**
- `req.params.id` - Gets ID from URL path
- Transaction ensures seat count is restored when cancelling

---

## 🔑 Key Node.js Concepts

### 1. Async/Await
```javascript
async function getData() {
    const [rows] = await db.query('SELECT * FROM users');
    return rows;
}
```
- Cleaner than callbacks or promises
- `await` pauses execution until promise resolves
- Must be inside `async` function

### 2. Express Middleware
```javascript
app.use(cors());
app.use(bodyParser.json());
```
- Functions that process requests before reaching routes
- Execute in order they're defined
- Can modify req/res objects

### 3. Route Parameters
```javascript
router.get('/:id', async (req, res) => {
    const id = req.params.id;
});
```
- `:id` is a URL parameter
- Accessed via `req.params.id`
- Example: `/api/events/5` → `id = 5`

### 4. Destructuring
```javascript
const { email, password } = req.body;
const [rows, fields] = await db.query();
```
- Extracts values from objects/arrays
- Cleaner than `req.body.email`

### 5. Environment Variables
```javascript
const PORT = process.env.PORT || 8080;
```
- Loaded from `.env` file via `dotenv`
- Keeps sensitive data out of code
- `||` provides default value

### 6. Connection Pooling
```javascript
const pool = mysql.createPool({ connectionLimit: 10 });
```
- Reuses database connections
- More efficient than creating new connections
- Handles concurrent requests

### 7. Error Handling
```javascript
try {
    // Database operations
} catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed' });
}
```
- Catches errors in async operations
- Prevents server crashes
- Returns error response to client

---

## 🔄 Request Flow Example

### User Registration Flow:

1. **Frontend** sends POST request:
   ```
   POST http://localhost:8080/api/auth/register
   Body: {"fullName":"John","email":"john@campus.edu","password":"pass123"}
   ```

2. **Express** receives request:
   - CORS middleware allows request
   - bodyParser converts JSON to JavaScript object
   - Routes to `/api/auth/register` handler

3. **Auth Route** processes:
   - Extracts data from `req.body`
   - Checks if email exists (SQL query)
   - Hashes password with bcrypt
   - Inserts user into database
   - Gets auto-generated user ID

4. **Database** executes:
   - MySQL2 sends parameterized query
   - Prevents SQL injection
   - Returns result with `insertId`

5. **Response** flows back:
   - Route sends JSON response
   - Express converts to HTTP response
   - Frontend receives: `{"userId":1,"email":"john@campus.edu","message":"Registration successful"}`

---

## 📊 Database Interaction

### Parameterized Queries
```javascript
db.query('SELECT * FROM users WHERE email = ?', [email])
```
- `?` is placeholder for value
- MySQL2 escapes values automatically
- Prevents SQL injection

### Promise-based
```javascript
const [rows] = await db.query('SELECT ...');
```
- Returns promise that resolves to `[rows, fields]`
- Use `await` to get results
- Cleaner than callbacks

### Transactions
```javascript
await connection.beginTransaction();
// Multiple queries
await connection.commit();
```
- Groups multiple queries
- All succeed or all fail
- Ensures data consistency

---

## 🔒 Security Features

1. **Password Hashing**
   - bcryptjs with 10 salt rounds
   - One-way encryption
   - Cannot be reversed

2. **SQL Injection Prevention**
   - Parameterized queries with `?`
   - MySQL2 escapes values automatically
   - Never concatenate user input into SQL

3. **CORS Configuration**
   - Only allows specific origins
   - Prevents unauthorized API access
   - Configured in `server.js`

4. **Environment Variables**
   - Sensitive data in `.env` file
   - Not committed to version control
   - Different values per environment

---

## 🚀 Application Startup

1. **Node.js starts** - Runs `server.js`
2. **Load dependencies** - Express, MySQL2, bcryptjs, CORS
3. **Load environment variables** from `.env`
4. **Create database connection pool**
5. **Setup middleware** - CORS, body parser
6. **Register routes** - Auth, Events, Categories, Registrations
7. **Start HTTP server** - Listens on port 8080

---

## 📝 Summary

The Node.js backend uses a **simple layered architecture**:

1. **Server Layer** - Express app setup and middleware
2. **Routes Layer** - API endpoints and request handling
3. **Database Layer** - MySQL connection and queries

**Benefits:**
- ✅ Simple and lightweight
- ✅ Fast startup time
- ✅ JavaScript everywhere (frontend + backend)
- ✅ Large npm ecosystem
- ✅ Async/await for clean code
- ✅ Connection pooling for performance
- ✅ Transaction support for data integrity

**Node.js Advantages:**
- Same language as frontend
- Non-blocking I/O
- Great for real-time applications
- Easy to deploy
- Lower resource usage
- Huge community support
