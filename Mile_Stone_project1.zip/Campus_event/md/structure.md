# Project Structure

## 📁 Complete Directory Structure

```
campus-event-portal/
│
├── server/                           # Node.js/Express backend
│   ├── config/
│   │   └── database.js              # MySQL connection pool
│   ├── routes/
│   │   ├── auth.js                  # Authentication endpoints
│   │   ├── events.js                # Event CRUD
│   │   ├── categories.js            # Category management
│   │   └── registrations.js         # Registration management
│   ├── server.js                    # Main Express application
│   ├── package.json                 # npm dependencies
│   ├── .env                         # Environment variables
│   ├── .env.example                 # Environment template
│   └── README.md                    # Backend documentation
│
├── css/                               # Frontend stylesheets
│   ├── style.css                     # Global Lunaria theme styles
│   ├── layout.css                    # Grid/Flexbox layouts
│   └── forms.css                     # Form styling
│
├── js/                                # Frontend JavaScript
│   ├── config.js                     # API endpoints configuration
│   ├── auth.js                       # Login/Register with API calls
│   ├── events.js                     # Event loading & registration
│   ├── dashboard.js                  # User dashboard functionality
│   └── main.js                       # Global interactions
│
├── sql/                               # Database scripts
│   ├── setup.sql                     # Complete database setup
│   ├── campus.sql                    # Table definitions (alternative)
│   ├── campus_events.sql             # Table definitions (alternative)
│   └── inserts.sql                   # Sample data
│
├── assets/
│   └── images/                       # Event banners, logos
│
├── md/                               # Documentation directory
│   ├── README.md                     # Main documentation
│   ├── structure.md                  # This file
│   └── explanation.md                # Backend explanation
├── index.html                        # Home page
├── register.html                     # User registration
├── login.html                        # User login
├── events.html                       # Events listing
├── event_registration.html           # Event registration form
├── dashboard.html                    # User dashboard
├── admin.html                        # Admin panel
├── create_event.html                 # Event creation page
├── payment.html                      # Payment processing page
├── TEST_API.html                     # API testing page
└── verify-setup.bat                  # Setup verification script
```

## 🔄 Data Flow

### User Registration Flow
```
register.html → js/auth.js → POST /api/auth/register → auth.js route
→ bcrypt.hash() → MySQL INSERT → Response JSON
```

### Event Loading Flow
```
events.html → js/events.js → GET /api/events/upcoming → events.js route
→ MySQL SELECT with JOIN → JSON response → Display events
```

### Event Registration Flow
```
event_registration.html → js/events.js → POST /api/registrations
→ registrations.js route → Transaction BEGIN → INSERT registration
→ UPDATE available_seats → COMMIT → Response JSON
```

## 🗄️ Database Tables

### users
- Stores user accounts (students and admins)
- Password hashed with BCrypt
- Unique email and student_id

### events
- Event details with date, location, capacity
- Links to categories and creator (user)
- Tracks available_seats

### registrations
- Links users to events they registered for
- Status: confirmed, attended, cancelled
- Unique constraint on (user_id, event_id)

### categories
- Event categories: Workshop, Seminar, Sports, Cultural
- Referenced by events table

## 🔌 API Architecture

### REST Endpoints Pattern
```
/api/auth/*          - Authentication
/api/events/*        - Event management
/api/registrations/* - Registration management
/api/categories/*    - Category management
```

### Request/Response Flow
```
Frontend (JS) → Fetch API → Express Route Handler → MySQL2 Query
→ MySQL Database → JSON Response → Frontend Update
```

## 🎨 Frontend Architecture

### Page Structure
- **index.html** - Landing page with featured events
- **events.html** - All events with category filtering
- **event_registration.html** - Single event registration
- **dashboard.html** - User's registered events
- **login.html** - User authentication
- **register.html** - New user registration
- **admin.html** - Admin management panel

### JavaScript Modules
- **config.js** - Centralized API endpoint configuration
- **auth.js** - Handles login/register API calls
- **events.js** - Fetches and displays events from API
- **dashboard.js** - Loads user registrations from API
- **payment.js** - Payment processing and PDF generation
- **create-event.js** - Event creation functionality
- **main.js** - Global functionality and featured events

### CSS Structure
- **style.css** - Lunaria color palette, global styles
- **layout.css** - Navigation, cards, grids
- **forms.css** - Form inputs, buttons, validation

## 🔐 Security Features

- BCrypt password hashing (cost factor 10)
- CORS configuration for specific origins
- SQL injection prevention via JPA/Hibernate
- Input validation on both frontend and backend
- Unique constraints on email and student_id

## 📦 Dependencies

### Backend (npm)
- express - Web framework
- mysql2 - MySQL database driver
- bcryptjs - Password hashing
- cors - Cross-origin resource sharing
- dotenv - Environment variables
- body-parser - Request body parsing

### Frontend
- No external dependencies
- Pure vanilla JavaScript
- Native Fetch API
- CSS3 with custom properties
- jsPDF for receipt generation

## 🚀 Deployment Structure

### Development
- Backend: localhost:8080 (Node.js/Express)
- Frontend: localhost:5500 (Python HTTP server or Live Server)
- Database: localhost:3306 (MySQL)

### Production
- Backend: Deploy to Heroku, AWS, DigitalOcean, or VPS
- Frontend: Static files to Netlify, Vercel, or web server
- Database: Remote MySQL instance (AWS RDS, PlanetScale, etc.)
- Update API_BASE_URL in config.js
- Use PM2 for Node.js process management