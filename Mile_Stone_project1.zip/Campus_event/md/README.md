# 🌙 Campus Event Portal

A full-stack web application for managing campus events with Node.js/Express backend and vanilla JavaScript frontend, featuring a refined Lunaria theme with elegant purple aesthetics.

## 🎨 Features

- **User Authentication** - Register and login with BCrypt password encryption
- **Event Management** - Browse, filter, and register for campus events
- **Category Filtering** - Workshop, Seminar, Sports, Cultural
- **Seat Management** - Real-time availability tracking
- **User Dashboard** - View and manage event registrations
- **Admin Panel** - Event creation and management
- **Payment System** - Integrated fake payment gateway with PDF receipt generation
- **Event Creation** - Dedicated interface for creating new events
- **Responsive Design** - Refined Lunaria theme with elegant purple palette

## 🛠️ Tech Stack

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web framework
- **MySQL2** - Database driver
- **bcryptjs** - Password hashing
- **npm** - Package manager

### Frontend
- **HTML5/CSS3** - Structure and styling
- **Vanilla JavaScript** - Dynamic functionality
- **Fetch API** - REST API communication
- **jsPDF** - PDF receipt generation
- **Refined Lunaria Theme** - Elegant purple color palette

## 📋 Prerequisites

- Node.js 16+ and npm
- MySQL 8.0+
- Python 3.x (for frontend server) OR VS Code Live Server

## 🚀 Quick Start

### 1. Setup Database

```bash
# Login to MySQL
mysql -u root -p

# Run setup script
source sql/setup.sql

# (Optional) Insert sample data
source sql/inserts.sql
```

### 2. Install Node.js Dependencies

```bash
cd server
npm install
```

### 3. Configure Backend

Create `server/.env` file:
```env
PORT=8080
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=YOUR_PASSWORD
DB_NAME=campus_events_db
DB_PORT=3306
```

### 4. Start Node.js Backend

```bash
cd server
npm start
```

✅ Wait for: `🚀 Server running on http://localhost:8080`

API runs on: **http://localhost:8080**

### 5. Start Frontend Server

Open a new terminal:

```bash
# Option 1: Python
python -m http.server 5500

# Option 2: VS Code Live Server
# Right-click index.html -> Open with Live Server
```

Frontend runs on: **http://localhost:5500**

### 6. Test & Use

- **Test API:** http://localhost:5500/TEST_API.html
- **Main App:** http://localhost:5500/index.html

## 📁 Project Structure

```
campus-event-portal/
├── server/                     # Node.js backend
│   ├── config/                 # Database configuration
│   │   └── database.js        # MySQL connection pool
│   ├── routes/                 # API routes
│   │   ├── auth.js            # Authentication
│   │   ├── events.js          # Events
│   │   ├── categories.js      # Categories
│   │   └── registrations.js   # Registrations
│   ├── server.js              # Main server file
│   ├── package.json           # npm dependencies
│   ├── .env                   # Environment config
│   └── README.md
├── css/                        # Stylesheets
│   ├── style.css              # Global Lunaria theme
│   ├── layout.css             # Grid/Flexbox layouts
│   └── forms.css              # Form styling
├── js/                         # JavaScript files
│   ├── config.js              # API configuration
│   ├── auth.js                # Authentication
│   ├── events.js              # Event management
│   ├── dashboard.js           # Dashboard functionality
│   └── main.js                # Global interactions
├── sql/                        # Database scripts
│   ├── setup.sql              # Database & tables
│   ├── campus.sql             # Table definitions
│   ├── campus_events.sql      # Alternative schema
│   └── inserts.sql            # Sample data
├── md/                         # Documentation files
│   ├── README.md              # Main documentation
│   ├── structure.md           # Project structure details
│   └── explanation.md         # Backend explanation
├── *.html                      # HTML pages
└── TEST_API.html              # API testing page
```

## 🔌 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/user/{id}` - Get user details

### Events
- `GET /api/events` - Get all events
- `GET /api/events/upcoming` - Get upcoming events
- `GET /api/events/{id}` - Get event by ID
- `GET /api/events/category/{categoryId}` - Filter by category
- `POST /api/events` - Create event (admin)
- `PUT /api/events/{id}` - Update event (admin)
- `DELETE /api/events/{id}` - Delete event (admin)

### Registrations
- `POST /api/registrations` - Register for event
- `GET /api/registrations/user/{userId}` - User's registrations
- `GET /api/registrations/event/{eventId}` - Event registrations
- `DELETE /api/registrations/{id}` - Cancel registration

### Categories
- `GET /api/categories` - Get all categories
- `POST /api/categories` - Create category (admin)

## 🗄️ Database Schema

### users
- `user_id` (PK)
- `full_name`
- `email` (unique)
- `student_id` (unique)
- `password_hash`
- `role` (student/admin)
- `created_at`

### events
- `event_id` (PK)
- `title`
- `description`
- `event_date`
- `location`
- `category_id` (FK)
- `capacity`
- `available_seats`
- `banner_img`
- `created_by` (FK)
- `created_at`

### registrations
- `registration_id` (PK)
- `user_id` (FK)
- `event_id` (FK)
- `registration_date`
- `status` (confirmed/attended/cancelled)

### categories
- `category_id` (PK)
- `category_name` (unique)

## 🎨 Refined Lunaria Color Palette

```css
--lunaria-primary: #6B4E9B        /* Main purple */
--lunaria-primary-dark: #4B2E7B   /* Dark purple */
--lunaria-secondary: #8B7BA8      /* Soft lavender */
--lunaria-accent: #9D7FBF         /* Light purple */
--lunaria-light: #E8DFF5          /* Very light purple */
--lunaria-bg: #F5F2F9             /* Background */
--lunaria-card: #FFFFFF           /* Card background */
--lunaria-text: #2D1B4E           /* Text color */
--lunaria-border: #D4C5E8         /* Border color */
```

## 🔧 Troubleshooting

### Backend won't start
- Check Node.js version: `node --version` (need 16+)
- Run `npm install` in server folder
- Verify MySQL is running
- Check database credentials in `server/.env`

### Frontend shows no data
- Verify backend is running on port 8080
- Check browser console (F12) for errors
- Test API: `http://localhost:8080/api/events`
- Ensure frontend runs on port 5500 (CORS configured)

### CORS errors
- Frontend must run on port 5500 or 3000
- Check CORS configuration in `server/server.js`

### Database connection failed
```bash
# Test MySQL connection
mysql -u root -p -e "USE campus_events_db; SHOW TABLES;"
```

## 📝 Usage

1. **Register/Login** - Create account or login
2. **Browse Events** - View and filter events by category
3. **Register for Events** - Click "Register & Pay" and complete payment
4. **Create Events** - Admin can create new events
5. **Dashboard** - View your registered events

## 🧪 Testing

Test API: http://localhost:5500/TEST_API.html

## 🚀 Deployment

**Backend:** Deploy to Heroku, AWS, DigitalOcean, or any VPS
**Frontend:** Deploy to Netlify, Vercel, or any web server
**Database:** Use AWS RDS, PlanetScale, or managed MySQL

Update `js/config.js` with production API URL.

## 📄 License

MIT License
