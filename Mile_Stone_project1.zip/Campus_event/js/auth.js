// Login/Register validation logic - Node.js Backend Integration
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const loginData = {
                email: document.getElementById('email').value,
                password: document.getElementById('password').value
            };
            
            try {
                const response = await apiCall(API_ENDPOINTS.LOGIN, {
                    method: 'POST',
                    body: JSON.stringify(loginData)
                });
                
                // Store user data in localStorage
                localStorage.setItem('userId', response.userId);
                localStorage.setItem('userEmail', response.email);
                localStorage.setItem('userName', response.fullName);
                localStorage.setItem('userRole', response.role);
                
                alert('Login successful!');
                window.location.href = 'dashboard.html';
            } catch (error) {
                showError(error.message || 'Login failed. Please check your credentials.');
            }
        });
    }
    
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const password = document.getElementById('password').value;
            
            // Validate password length
            if (password.length < 6) {
                showError('Password must be at least 6 characters');
                return;
            }
            
            const registerData = {
                fullName: document.getElementById('fullName').value,
                email: document.getElementById('email').value,
                studentId: document.getElementById('studentId').value,
                password: password,
                role: document.getElementById('role').value
            };
            
            try {
                const response = await apiCall(API_ENDPOINTS.REGISTER, {
                    method: 'POST',
                    body: JSON.stringify(registerData)
                });
                
                alert('Registration successful! Please login with your credentials.');
                window.location.href = 'login.html';
            } catch (error) {
                showError(error.message || 'Registration failed. Please try again.');
            }
        });
    }
    
    function showError(message) {
        const errorDiv = document.getElementById('errorMessage');
        if (errorDiv) {
            errorDiv.textContent = message;
            errorDiv.style.display = 'block';
            
            setTimeout(() => {
                errorDiv.style.display = 'none';
            }, 5000);
        }
    }
});
