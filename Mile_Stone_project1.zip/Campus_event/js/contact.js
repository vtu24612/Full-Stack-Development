// Contact form handling
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactSubmit);
    }
});

async function handleContactSubmit(e) {
    e.preventDefault();
    
    const formData = {
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        subject: document.getElementById('subject').value,
        message: document.getElementById('message').value
    };
    
    // Show loading message
    showContactMessage('Sending your message...', 'info');
    
    // Simulate sending (in production, this would call a backend API)
    setTimeout(() => {
        console.log('Contact form submitted:', formData);
        
        showContactMessage('Thank you for contacting us! We will get back to you within 24 hours.', 'success');
        
        // Reset form
        document.getElementById('contactForm').reset();
        
        // Hide message after 5 seconds
        setTimeout(() => {
            document.getElementById('contactMessage').style.display = 'none';
        }, 5000);
    }, 1500);
}

function showContactMessage(message, type) {
    const messageDiv = document.getElementById('contactMessage');
    messageDiv.textContent = message;
    messageDiv.className = type === 'success' ? 'success-message' : 
                          type === 'error' ? 'error-message' : 'info-message';
    messageDiv.style.display = 'block';
}
