// Dynamic event rendering and registration logic - Node.js Backend Integration
document.addEventListener('DOMContentLoaded', async function() {
    const eventsContainer = document.getElementById('eventsContainer');
    
    // Load events from API
    if (eventsContainer) {
        await loadEvents();
    }
    
    // Filter functionality
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(button => {
        button.addEventListener('click', async function() {
            const category = this.getAttribute('data-category');
            
            // Update active button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Load filtered events
            await loadEvents(category);
        });
    });
    
    // Event registration form
    const eventRegForm = document.getElementById('eventRegistrationForm');
    if (eventRegForm) {
        await loadEventDetails();
        
        eventRegForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const userId = localStorage.getItem('userId');
            if (!userId) {
                alert('Please login to register for events');
                window.location.href = 'login.html';
                return;
            }
            
            const eventId = document.getElementById('eventId').value;
            
            const registrationData = {
                userId: parseInt(userId),
                eventId: parseInt(eventId)
            };
            
            try {
                await apiCall(API_ENDPOINTS.REGISTER_FOR_EVENT, {
                    method: 'POST',
                    body: JSON.stringify(registrationData)
                });
                
                const messageDiv = document.getElementById('registrationMessage');
                messageDiv.innerHTML = '<p style="color: #7FFF9F; font-weight: bold;">✓ Registration successful!</p>';
                
                setTimeout(() => {
                    window.location.href = 'dashboard.html';
                }, 2000);
            } catch (error) {
                const messageDiv = document.getElementById('registrationMessage');
                messageDiv.innerHTML = `<p style="color: #ff6b9d; font-weight: bold;">✗ ${error.message}</p>`;
            }
        });
    }
});

async function loadEvents(category = 'all') {
    const eventsContainer = document.getElementById('eventsContainer');
    if (!eventsContainer) return;
    
    try {
        eventsContainer.innerHTML = '<p style="text-align: center; color: var(--lunaria-glow);">Loading events...</p>';
        
        const events = await apiCall(API_ENDPOINTS.GET_UPCOMING_EVENTS);
        
        // Filter by category if needed
        const filteredEvents = category === 'all' 
            ? events 
            : events.filter(event => {
                const eventCategory = event.category_name || '';
                return eventCategory.toLowerCase() === category;
            });
        
        if (filteredEvents.length === 0) {
            eventsContainer.innerHTML = '<p style="text-align: center; color: var(--lunaria-glow);">No events found.</p>';
            return;
        }
        
        eventsContainer.innerHTML = filteredEvents.map(event => {
            const eventDate = new Date(event.event_date);
            const formattedDate = eventDate.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
            
            const categoryName = event.category_name || 'General';
            const seatsAvailable = event.available_seats || 0;
            const totalCapacity = event.capacity || 0;
            const registeredCount = totalCapacity - seatsAvailable;
            const isFullyBooked = seatsAvailable <= 0;
            const seatsText = isFullyBooked ? 'Fully Booked' : `${seatsAvailable} seats available`;
            
            // Check if user is admin
            const userRole = localStorage.getItem('userRole');
            const isAdmin = userRole === 'admin';
            
            return `
                <div class="event-card ${isFullyBooked ? 'fully-booked' : ''}" data-category="${categoryName.toLowerCase()}">
                    <h3>${event.title}</h3>
                    <p><strong>Date:</strong> ${formattedDate}</p>
                    <p>${event.description || 'No description available'}</p>
                    <p><strong>Location:</strong> ${event.location}</p>
                    <p><em style="color: ${isFullyBooked ? '#ff6b9d' : 'inherit'};">${seatsText}</em></p>
                    <p style="color: var(--lunaria-text-light); font-size: 0.9rem;">
                        ${registeredCount} registered / ${totalCapacity} capacity
                    </p>
                    ${!isFullyBooked ? 
                        `<a href="payment.html?eventId=${event.event_id}" class="btn btn-primary">Register & Pay</a>` : 
                        `<button class="btn btn-secondary" disabled>Fully Booked</button>`
                    }
                    ${isAdmin ? 
                        `<button class="btn btn-danger" onclick="deleteEvent(${event.event_id})" style="margin-top: 0.5rem;">Delete Event</button>` : 
                        ''
                    }
                </div>
            `;
        }).join('');
    } catch (error) {
        eventsContainer.innerHTML = '<p style="text-align: center; color: #ff6b9d;">Failed to load events. Please try again later.</p>';
        console.error('Error loading events:', error);
    }
}

async function loadEventDetails() {
    const urlParams = new URLSearchParams(window.location.search);
    const eventId = urlParams.get('id');
    
    if (!eventId) {
        alert('Invalid event');
        window.location.href = 'events.html';
        return;
    }
    
    try {
        const event = await apiCall(API_ENDPOINTS.GET_EVENT_BY_ID(eventId));
        
        const eventDate = new Date(event.event_date);
        const formattedDate = eventDate.toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        document.getElementById('eventId').value = event.event_id;
        document.getElementById('eventTitle').textContent = event.title;
        document.getElementById('eventDescription').textContent = event.description || 'No description available';
        document.getElementById('eventDate').textContent = formattedDate;
        document.getElementById('eventLocation').textContent = event.location;
        document.getElementById('availableSeats').textContent = `${event.available_seats}/${event.capacity}`;
    } catch (error) {
        alert('Failed to load event details');
        window.location.href = 'events.html';
    }
}


async function deleteEvent(eventId) {
    if (!confirm('Are you sure you want to delete this event? This action cannot be undone.')) {
        return;
    }
    
    try {
        await apiCall(API_ENDPOINTS.DELETE_EVENT(eventId), {
            method: 'DELETE'
        });
        
        alert('Event deleted successfully!');
        await loadEvents(); // Reload events
    } catch (error) {
        alert('Failed to delete event: ' + error.message);
    }
}

// Update navigation on page load
document.addEventListener('DOMContentLoaded', function() {
    updateNavigation();
});

function updateNavigation() {
    const userId = localStorage.getItem('userId');
    const userName = localStorage.getItem('userName');
    const userRole = localStorage.getItem('userRole');
    
    const navLogin = document.getElementById('navLogin');
    const navSignup = document.getElementById('navSignup');
    const navLogout = document.getElementById('navLogout');
    const navDashboard = document.getElementById('navDashboard');
    const navCreateEvent = document.getElementById('navCreateEvent');
    
    if (userId && userName) {
        if (navLogin) navLogin.style.display = 'none';
        if (navSignup) navSignup.style.display = 'none';
        if (navLogout) navLogout.style.display = 'block';
        if (navDashboard) navDashboard.style.display = 'block';
        
        if (navCreateEvent && userRole === 'admin') {
            navCreateEvent.style.display = 'block';
        }
        
        applyTheme(userRole);
    } else {
        if (navLogin) navLogin.style.display = 'block';
        if (navSignup) navSignup.style.display = 'block';
        if (navLogout) navLogout.style.display = 'none';
        if (navDashboard) navDashboard.style.display = 'none';
        if (navCreateEvent) navCreateEvent.style.display = 'none';
    }
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('userId');
        localStorage.removeItem('userName');
        localStorage.removeItem('userEmail');
        localStorage.removeItem('userRole');
        alert('Logged out successfully!');
        window.location.href = 'index.html';
    }
}

function applyTheme(role) {
    const root = document.documentElement;
    
    if (role === 'admin') {
        root.style.setProperty('--lunaria-primary', '#D97706');
        root.style.setProperty('--lunaria-primary-dark', '#B45309');
        root.style.setProperty('--lunaria-secondary', '#F59E0B');
        root.style.setProperty('--lunaria-accent', '#FBBF24');
        root.style.setProperty('--lunaria-light', '#FEF3C7');
    } else {
        root.style.setProperty('--lunaria-primary', '#6B4E9B');
        root.style.setProperty('--lunaria-primary-dark', '#4B2E7B');
        root.style.setProperty('--lunaria-secondary', '#8B7BA8');
        root.style.setProperty('--lunaria-accent', '#9D7FBF');
        root.style.setProperty('--lunaria-light', '#E8DFF5');
    }
}
