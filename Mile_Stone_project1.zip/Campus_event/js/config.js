// API Configuration
const API_BASE_URL = 'http://localhost:8080/api';

const API_ENDPOINTS = {
    // Auth
    LOGIN: `${API_BASE_URL}/auth/login`,
    REGISTER: `${API_BASE_URL}/auth/register`,
    GET_USER: (id) => `${API_BASE_URL}/auth/user/${id}`,
    
    // Events
    GET_ALL_EVENTS: `${API_BASE_URL}/events`,
    GET_UPCOMING_EVENTS: `${API_BASE_URL}/events/upcoming`,
    GET_EVENT_BY_ID: (id) => `${API_BASE_URL}/events/${id}`,
    GET_EVENTS_BY_CATEGORY: (categoryId) => `${API_BASE_URL}/events/category/${categoryId}`,
    CREATE_EVENT: `${API_BASE_URL}/events`,
    UPDATE_EVENT: (id) => `${API_BASE_URL}/events/${id}`,
    DELETE_EVENT: (id) => `${API_BASE_URL}/events/${id}`,
    DELETE_EVENT: (id) => `${API_BASE_URL}/events/${id}`,
    
    // Registrations
    REGISTER_FOR_EVENT: `${API_BASE_URL}/registrations`,
    GET_USER_REGISTRATIONS: (userId) => `${API_BASE_URL}/registrations/user/${userId}`,
    GET_EVENT_REGISTRATIONS: (eventId) => `${API_BASE_URL}/registrations/event/${eventId}`,
    CANCEL_REGISTRATION: (id) => `${API_BASE_URL}/registrations/${id}`,
    UPDATE_REGISTRATION_STATUS: (id) => `${API_BASE_URL}/registrations/${id}/status`,
    
    // Categories
    GET_ALL_CATEGORIES: `${API_BASE_URL}/categories`,
    CREATE_CATEGORY: `${API_BASE_URL}/categories`
};

// Helper function for API calls
async function apiCall(url, options = {}) {
    try {
        const response = await fetch(url, {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            }
        });
        
        if (!response.ok) {
            const error = await response.text();
            throw new Error(error || 'API request failed');
        }
        
        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}
