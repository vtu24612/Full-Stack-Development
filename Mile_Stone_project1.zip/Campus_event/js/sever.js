// server.js - Node.js Express Backend
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bcrypt = require('bcrypt'); // For secure password hashing
const app = express();

app.use(cors());
app.use(express.json());

// 1. Database Connection Pool (Production Standard)
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'your_production_password',
    database: 'campus_events_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// 2. Example API Endpoint: Get All Events
app.get('/api/events', (req, res) => {
    db.query('SELECT * FROM events', (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// 3. Example API Endpoint: Register User
app.post('/api/register', async (req, res) => {
    const { full_name, email, password } = req.body;

    // Securely hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    const query = 'INSERT INTO users (full_name, email, password_hash) VALUES (?, ?, ?)';
    db.query(query, [full_name, email, hashedPassword], (err, result) => {
        if (err) return res.status(500).json({ error: 'Registration failed' });
        res.status(201).json({ message: 'User registered' });
    });
});

app.listen(3000, () => console.log('Server running on port 3000'));