// Payment processing and PDF receipt generation
let eventData = null;
let registrationData = null;

document.addEventListener('DOMContentLoaded', async function() {
    await loadEventSummary();
    
    const form = document.getElementById('paymentForm');
    form.addEventListener('submit', handlePayment);
    
    // Format card number input
    document.getElementById('cardNumber').addEventListener('input', formatCardNumber);
    document.getElementById('expiryDate').addEventListener('input', formatExpiryDate);
    document.getElementById('cvv').addEventListener('input', formatCVV);
});

async function loadEventSummary() {
    const urlParams = new URLSearchParams(window.location.search);
    const eventId = urlParams.get('eventId');
    
    if (!eventId) {
        alert('Invalid payment request');
        window.location.href = 'events.html';
        return;
    }
    
    try {
        eventData = await apiCall(API_ENDPOINTS.GET_EVENT_BY_ID(eventId));
        
        const eventDate = new Date(eventData.eventDate);
        const formattedDate = eventDate.toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        // Calculate price (fake pricing: ₹500 per event)
        const price = 500.00;
        
        document.getElementById('eventSummary').innerHTML = `
            <div style="margin-bottom: 1rem;">
                <h3 style="margin-bottom: 0.5rem;">${eventData.title}</h3>
                <p style="color: var(--text-secondary); margin: 0.25rem 0;">
                    <strong>Date:</strong> ${formattedDate}
                </p>
                <p style="color: var(--text-secondary); margin: 0.25rem 0;">
                    <strong>Location:</strong> ${eventData.location}
                </p>
                <p style="color: var(--text-secondary); margin: 0.25rem 0;">
                    <strong>Price:</strong> ₹${price.toFixed(2)}
                </p>
            </div>
        `;
        
        document.getElementById('totalAmount').textContent = `₹${price.toFixed(2)}`;
        
        // Pre-fill email if user is logged in
        const userEmail = localStorage.getItem('userEmail');
        if (userEmail) {
            document.getElementById('email').value = userEmail;
        }
    } catch (error) {
        console.error('Error loading event:', error);
        alert('Failed to load event details');
        window.location.href = 'events.html';
    }
}

async function handlePayment(e) {
    e.preventDefault();
    
    const userId = localStorage.getItem('userId');
    if (!userId) {
        alert('Please login to complete payment');
        window.location.href = 'login.html';
        return;
    }
    
    // Validate card details (fake validation)
    const cardNumber = document.getElementById('cardNumber').value.replace(/\s/g, '');
    const cvv = document.getElementById('cvv').value;
    const expiryDate = document.getElementById('expiryDate').value;
    
    if (cardNumber.length !== 16) {
        showPaymentMessage('Invalid card number', 'error');
        return;
    }
    
    if (cvv.length !== 3) {
        showPaymentMessage('Invalid CVV', 'error');
        return;
    }
    
    showPaymentMessage('Processing payment...', 'info');
    
    // Simulate payment processing
    setTimeout(async () => {
        try {
            // Register for event
            const registrationRequest = {
                userId: parseInt(userId),
                eventId: eventData.event_id
            };
            
            registrationData = await apiCall(API_ENDPOINTS.REGISTER_FOR_EVENT, {
                method: 'POST',
                body: JSON.stringify(registrationRequest)
            });
            
            showPaymentMessage('Payment successful! Generating receipt...', 'success');
            
            // Generate PDF receipt
            setTimeout(() => {
                generatePDFReceipt();
                
                // Simulate sending email
                sendReceiptEmail();
                
                showPaymentMessage('Receipt generated and sent to your email!', 'success');
                
                setTimeout(() => {
                    window.location.href = 'dashboard.html';
                }, 3000);
            }, 1000);
            
        } catch (error) {
            showPaymentMessage('Payment failed: ' + error.message, 'error');
        }
    }, 2000);
}

function generatePDFReceipt() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    
    // Header
    doc.setFontSize(20);
    doc.setTextColor(75, 46, 131); // Lunaria purple
    doc.text('Campus Events', 105, 20, { align: 'center' });
    
    doc.setFontSize(16);
    doc.text('Payment Receipt', 105, 30, { align: 'center' });
    
    // Line
    doc.setDrawColor(75, 46, 131);
    doc.line(20, 35, 190, 35);
    
    // Receipt details
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);
    
    const receiptDate = new Date().toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
    
    doc.text(`Receipt Date: ${receiptDate}`, 20, 50);
    doc.text(`Receipt #: RCP-${Date.now()}`, 20, 58);
    
    // Event details
    doc.setFontSize(14);
    doc.setTextColor(75, 46, 131);
    doc.text('Event Details', 20, 75);
    
    doc.setFontSize(11);
    doc.setTextColor(0, 0, 0);
    doc.text(`Event: ${eventData.title}`, 20, 85);
    doc.text(`Date: ${new Date(eventData.event_date).toLocaleDateString()}`, 20, 93);
    doc.text(`Location: ${eventData.location}`, 20, 101);
    
    // Payment details
    doc.setFontSize(14);
    doc.setTextColor(75, 46, 131);
    doc.text('Payment Details', 20, 120);
    
    doc.setFontSize(11);
    doc.setTextColor(0, 0, 0);
    doc.text(`Cardholder: ${document.getElementById('cardName').value}`, 20, 130);
    doc.text(`Card: **** **** **** ${document.getElementById('cardNumber').value.slice(-4)}`, 20, 138);
    doc.text(`Amount Paid: ₹500.00`, 20, 146);
    doc.text(`Payment Status: SUCCESSFUL`, 20, 154);
    
    // Footer
    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text('Thank you for registering!', 105, 180, { align: 'center' });
    doc.text('This is an automatically generated receipt.', 105, 188, { align: 'center' });
    
    // Line
    doc.setDrawColor(75, 46, 131);
    doc.line(20, 195, 190, 195);
    
    doc.text('Campus Event Portal - Making campus life better', 105, 203, { align: 'center' });
    
    // Save PDF
    doc.save(`receipt-${eventData.event_id}-${Date.now()}.pdf`);
}

function sendReceiptEmail() {
    // Simulate email sending (in production, this would be a backend API call)
    const email = document.getElementById('email').value;
    console.log(`Receipt sent to: ${email}`);
    
    // In production, you would call a backend endpoint:
    // await apiCall('/api/email/send-receipt', {
    //     method: 'POST',
    //     body: JSON.stringify({
    //         email: email,
    //         eventId: eventData.event_id,
    //         receiptData: { ... }
    //     })
    // });
}

function formatCardNumber(e) {
    let value = e.target.value.replace(/\s/g, '');
    let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
    e.target.value = formattedValue;
}

function formatExpiryDate(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length >= 2) {
        value = value.slice(0, 2) + '/' + value.slice(2, 4);
    }
    e.target.value = value;
}

function formatCVV(e) {
    e.target.value = e.target.value.replace(/\D/g, '').slice(0, 3);
}

function showPaymentMessage(message, type) {
    const messageDiv = document.getElementById('paymentMessage');
    messageDiv.textContent = message;
    messageDiv.className = type === 'success' ? 'success-message' : 
                          type === 'error' ? 'error-message' : 'info-message';
    messageDiv.style.display = 'block';
}
