// Global interactions - Node.js Backend Integration
document.addEventListener('DOMContentLoaded', async function() {
    console.log('Campus Event Portal loaded with Lunaria theme');
    
    // Load featured events on home page
    const featuredContainer = document.getElementById('featured-events');
    if (featuredContainer) {
        await loadFeaturedEvents();
    }
    
    // Add smooth scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Check if user is logged in and update nav
    updateNavigation();
});

async function loadFeaturedEvents() {
    const container = document.getElementById('featured-events');
    if (!container) return;
    
    try {
        const events = await apiCall(API_ENDPOINTS.GET_UPCOMING_EVENTS);
        const featuredEvents = events.slice(0, 3); // Get first 3 events
        
        container.innerHTML = featuredEvents.map(event => {
            const eventDate = new Date(event.event_date);
            const formattedDate = eventDate.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
            
            const seatsAvailable = event.available_seats || 0;
            const totalCapacity = event.capacity || 0;
            const registeredCount = totalCapacity - seatsAvailable;
            const isFullyBooked = seatsAvailable <= 0;
            const seatsText = isFullyBooked ? 'Fully Booked' : `${seatsAvailable} seats available`;
            
            return `
                <div class="event-card ${isFullyBooked ? 'fully-booked' : ''}">
                    <h3>${event.title}</h3>
                    <p><strong>Date:</strong> ${formattedDate}</p>
                    <p>${event.description || 'No description available'}</p>
                    <p><em style="color: ${isFullyBooked ? '#ff6b9d' : 'inherit'};">${seatsText}</em></p>
                    <p style="color: var(--lunaria-text-light); font-size: 0.9rem;">
                        ${registeredCount} registered / ${totalCapacity} capacity
                    </p>
                    ${!isFullyBooked ? 
                        `<a href="payment.html?eventId=${event.event_id}" class="btn btn-primary">Register & Pay (₹500)</a>` : 
                        `<button class="btn btn-secondary" disabled>Fully Booked</button>`
                    }
                </div>
            `;
        }).join('');
    } catch (error) {
        console.error('Error loading featured events:', error);
        container.innerHTML = '<p style="text-align: center; color: var(--lunaria-glow);">Unable to load events at this time.</p>';
    }
}

function updateNavigation() {
    const userId = localStorage.getItem('userId');
    const userName = localStorage.getItem('userName');
    const userRole = localStorage.getItem('userRole');
    
    const navLogin = document.getElementById('navLogin');
    const navSignup = document.getElementById('navSignup');
    const navLogout = document.getElementById('navLogout');
    const navDashboard = document.getElementById('navDashboard');
    const navCreateEvent = document.getElementById('navCreateEvent');
    
    if (userId && userName) {
        // User is logged in
        if (navLogin) navLogin.style.display = 'none';
        if (navSignup) navSignup.style.display = 'none';
        if (navLogout) navLogout.style.display = 'block';
        if (navDashboard) navDashboard.style.display = 'block';
        
        // Show Create Event only for admins
        if (navCreateEvent && userRole === 'admin') {
            navCreateEvent.style.display = 'block';
        }
        
        // Apply theme based on user role
        applyTheme(userRole);
    } else {
        // User is not logged in
        if (navLogin) navLogin.style.display = 'block';
        if (navSignup) navSignup.style.display = 'block';
        if (navLogout) navLogout.style.display = 'none';
        if (navDashboard) navDashboard.style.display = 'none';
        if (navCreateEvent) navCreateEvent.style.display = 'none';
    }
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('userId');
        localStorage.removeItem('userName');
        localStorage.removeItem('userEmail');
        localStorage.removeItem('userRole');
        alert('Logged out successfully!');
        window.location.href = 'index.html';
    }
}

function applyTheme(role) {
    const root = document.documentElement;
    
    if (role === 'admin') {
        // Admin theme - Orange/Red tones
        root.style.setProperty('--lunaria-primary', '#D97706');
        root.style.setProperty('--lunaria-primary-dark', '#B45309');
        root.style.setProperty('--lunaria-secondary', '#F59E0B');
        root.style.setProperty('--lunaria-accent', '#FBBF24');
        root.style.setProperty('--lunaria-light', '#FEF3C7');
    } else {
        // Student theme - Purple tones (default)
        root.style.setProperty('--lunaria-primary', '#6B4E9B');
        root.style.setProperty('--lunaria-primary-dark', '#4B2E7B');
        root.style.setProperty('--lunaria-secondary', '#8B7BA8');
        root.style.setProperty('--lunaria-accent', '#9D7FBF');
        root.style.setProperty('--lunaria-light', '#E8DFF5');
    }
}

