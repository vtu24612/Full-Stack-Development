// Dashboard - Load user registrations from Node.js API
document.addEventListener('DOMContentLoaded', async function() {
    const userId = localStorage.getItem('userId');
    
    if (!userId) {
        alert('Please login to view dashboard');
        window.location.href = 'login.html';
        return;
    }
    
    await loadUserRegistrations(userId);
    await loadStatistics(userId);
});

async function loadUserRegistrations(userId) {
    const container = document.getElementById('registeredEvents');
    if (!container) return;
    
    try {
        container.innerHTML = '<p style="text-align: center; color: var(--lunaria-glow);">Loading your registrations...</p>';
        
        const registrations = await apiCall(API_ENDPOINTS.GET_USER_REGISTRATIONS(userId));
        
        if (registrations.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: var(--lunaria-glow);">You have not registered for any events yet.</p>';
            return;
        }
        
        container.innerHTML = registrations.map(reg => {
            const eventDate = new Date(reg.event_date);
            const formattedDate = eventDate.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
            
            return `
                <div class="event-card">
                    <h3>${reg.title}</h3>
                    <p><strong>Date:</strong> ${formattedDate}</p>
                    <p><strong>Location:</strong> ${reg.location}</p>
                    <p><strong>Status:</strong> <span style="color: var(--lunaria-primary);">${reg.status}</span></p>
                    ${reg.status === 'confirmed' ? `
                        <button class="btn btn-secondary" onclick="cancelRegistration(${reg.registration_id})">
                            Cancel Registration
                        </button>
                    ` : ''}
                </div>
            `;
        }).join('');
    } catch (error) {
        container.innerHTML = '<p style="text-align: center; color: #ff6b9d;">Failed to load registrations.</p>';
        console.error('Error loading registrations:', error);
    }
}

async function loadStatistics(userId) {
    try {
        const registrations = await apiCall(API_ENDPOINTS.GET_USER_REGISTRATIONS(userId));
        const allEvents = await apiCall(API_ENDPOINTS.GET_UPCOMING_EVENTS);
        
        // Update statistics with actual counts
        const confirmedCount = registrations.filter(r => r.status === 'confirmed').length;
        const statCards = document.querySelectorAll('.event-card p[style*="font-size: 2.5rem"]');
        if (statCards.length >= 2) {
            statCards[0].textContent = confirmedCount;
            statCards[1].textContent = allEvents.length;
        }
    } catch (error) {
        console.error('Error loading statistics:', error);
    }
}

async function cancelRegistration(registrationId) {
    if (!confirm('Are you sure you want to cancel this registration?')) {
        return;
    }
    
    try {
        await apiCall(API_ENDPOINTS.CANCEL_REGISTRATION(registrationId), {
            method: 'DELETE'
        });
        
        alert('Registration cancelled successfully');
        location.reload();
    } catch (error) {
        alert('Failed to cancel registration: ' + error.message);
    }
}
