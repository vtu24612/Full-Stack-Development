// Create Event functionality
document.addEventListener('DOMContentLoaded', async function() {
    await loadCategories();
    
    const form = document.getElementById('createEventForm');
    form.addEventListener('submit', handleCreateEvent);
});

async function loadCategories() {
    try {
        const categories = await apiCall(API_ENDPOINTS.GET_ALL_CATEGORIES);
        const select = document.getElementById('category');
        
        categories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat.category_id;
            option.textContent = cat.category_name;
            select.appendChild(option);
        });
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

async function handleCreateEvent(e) {
    e.preventDefault();
    
    const userId = localStorage.getItem('userId');
    if (!userId) {
        showMessage('Please login to create events', 'error');
        window.location.href = 'login.html';
        return;
    }
    
    const formData = {
        title: document.getElementById('title').value,
        description: document.getElementById('description').value,
        eventDate: document.getElementById('eventDate').value,
        location: document.getElementById('location').value,
        categoryId: parseInt(document.getElementById('category').value),
        capacity: parseInt(document.getElementById('capacity').value),
        bannerImg: document.getElementById('bannerImg').value || 'default_event.jpg',
        createdBy: parseInt(userId)
    };
    
    try {
        const response = await apiCall(API_ENDPOINTS.CREATE_EVENT, {
            method: 'POST',
            body: JSON.stringify(formData)
        });
        
        showMessage('Event created successfully!', 'success');
        
        setTimeout(() => {
            window.location.href = 'events.html';
        }, 2000);
    } catch (error) {
        showMessage('Failed to create event: ' + error.message, 'error');
    }
}

function showMessage(message, type) {
    const messageDiv = document.getElementById('message');
    messageDiv.textContent = message;
    messageDiv.className = type === 'success' ? 'success-message' : 'error-message';
    messageDiv.style.display = 'block';
}
