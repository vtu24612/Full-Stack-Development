-- Populate Categories
INSERT INTO categories (category_name) VALUES ('Workshop'), ('Seminar'), ('Cultural'), ('Sports');

-- Create an Admin
INSERT INTO users (full_name, email, password_hash, role) 
VALUES ('Admin Account', 'admin@campus.edu', 'hashed_pass_xyz', 'admin');

-- Create a Sample Event (Linked to Category 1: Workshop)
INSERT INTO events (title, description, event_date, location, category_id, capacity, available_seats, created_by) 
VALUES ('Hackathon 2026', '24-hour coding challenge.', '2026-06-12 09:00:00', 'Tech Hall', 1, 100, 100, 1);