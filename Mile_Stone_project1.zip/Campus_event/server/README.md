# Campus Events - Node.js Backend

Node.js/Express REST API for Campus Event Portal with MySQL database.

## 🚀 Quick Start

### 1. Install Dependencies

```bash
cd server
npm install
```

### 2. Configure Database

Create `.env` file (copy from `.env.example`):

```bash
cp .env.example .env
```

Edit `.env` with your MySQL credentials:

```env
PORT=8080
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=campus_events_db
DB_PORT=3306
```

### 3. Setup Database

Make sure MySQL is running and execute the SQL scripts:

```bash
mysql -u root -p < ../sql/campus_events.sql
mysql -u root -p < ../sql/inserts.sql
```

### 4. Start Server

**Development mode (with auto-restart):**
```bash
npm run dev
```

**Production mode:**
```bash
npm start
```

Server runs on: **http://localhost:8080**

## 📁 Project Structure

```
server/
├── config/
│   └── database.js          # MySQL connection pool
├── routes/
│   ├── auth.js             # Authentication endpoints
│   ├── events.js           # Event management
│   ├── categories.js       # Category management
│   └── registrations.js    # Registration management
├── server.js               # Main application file
├── package.json            # Dependencies
├── .env.example            # Environment variables template
└── README.md               # This file
```

## 🔌 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/user/:id` - Get user details

### Events
- `GET /api/events` - Get all events
- `GET /api/events/upcoming` - Get upcoming events
- `GET /api/events/:id` - Get event by ID
- `GET /api/events/category/:categoryId` - Filter by category
- `POST /api/events` - Create event
- `PUT /api/events/:id` - Update event
- `DELETE /api/events/:id` - Delete event

### Registrations
- `POST /api/registrations` - Register for event
- `GET /api/registrations/user/:userId` - User's registrations
- `GET /api/registrations/event/:eventId` - Event registrations
- `DELETE /api/registrations/:id` - Cancel registration

### Categories
- `GET /api/categories` - Get all categories
- `GET /api/categories/:id` - Get category by ID
- `POST /api/categories` - Create category

## 🛠️ Technologies

- **Express.js** - Web framework
- **MySQL2** - Database driver with promise support
- **bcryptjs** - Password hashing
- **CORS** - Cross-origin resource sharing
- **dotenv** - Environment variables
- **body-parser** - Request body parsing

## 🔒 Security Features

- BCrypt password hashing (10 rounds)
- SQL injection prevention via parameterized queries
- CORS configuration for specific origins
- Transaction support for data integrity

## 🧪 Testing

Test the API using:
- Browser: http://localhost:5500/TEST_API.html
- Postman/Insomnia
- cURL commands

Example cURL:
```bash
# Get all events
curl http://localhost:8080/api/events

# Register user
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"fullName":"John Doe","email":"john@campus.edu","studentId":"S12345","password":"pass123","role":"student"}'
```

## 🔧 Troubleshooting

### Database connection failed
- Check MySQL is running: `mysql -u root -p`
- Verify credentials in `.env` file
- Ensure database exists: `SHOW DATABASES;`

### Port already in use
- Change PORT in `.env` file
- Kill process: `lsof -ti:8080 | xargs kill` (Mac/Linux)

### Module not found
- Run `npm install` again
- Delete `node_modules` and reinstall

## 📝 Development

Install nodemon for auto-restart:
```bash
npm install -g nodemon
npm run dev
```

## 🚀 Deployment

### Production Setup
1. Set environment variables on server
2. Use PM2 for process management:
```bash
npm install -g pm2
pm2 start server.js --name campus-events
pm2 save
pm2 startup
```

### Environment Variables
Ensure all production values are set:
- Database credentials
- PORT number
- CORS origins

## 📄 License

MIT License
