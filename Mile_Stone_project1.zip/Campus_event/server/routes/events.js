const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Get all events
router.get('/', async (req, res) => {
    try {
        const [events] = await db.query(`
            SELECT e.*, c.category_name, u.full_name as creator_name
            FROM events e
            LEFT JOIN categories c ON e.category_id = c.category_id
            LEFT JOIN users u ON e.created_by = u.user_id
            ORDER BY e.event_date DESC
        `);
        res.json(events);
    } catch (error) {
        console.error('Get events error:', error);
        res.status(500).json({ error: 'Failed to fetch events' });
    }
});

// Get upcoming events
router.get('/upcoming', async (req, res) => {
    try {
        const [events] = await db.query(`
            SELECT e.*, c.category_name, u.full_name as creator_name
            FROM events e
            LEFT JOIN categories c ON e.category_id = c.category_id
            LEFT JOIN users u ON e.created_by = u.user_id
            WHERE e.event_date >= NOW()
            ORDER BY e.event_date ASC
        `);
        res.json(events);
    } catch (error) {
        console.error('Get upcoming events error:', error);
        res.status(500).json({ error: 'Failed to fetch upcoming events' });
    }
});

// Get event by ID
router.get('/:id', async (req, res) => {
    try {
        const [events] = await db.query(`
            SELECT e.*, c.category_name, u.full_name as creator_name
            FROM events e
            LEFT JOIN categories c ON e.category_id = c.category_id
            LEFT JOIN users u ON e.created_by = u.user_id
            WHERE e.event_id = ?
        `, [req.params.id]);

        if (events.length === 0) {
            return res.status(404).json({ error: 'Event not found' });
        }

        res.json(events[0]);
    } catch (error) {
        console.error('Get event error:', error);
        res.status(500).json({ error: 'Failed to fetch event' });
    }
});

// Get events by category
router.get('/category/:categoryId', async (req, res) => {
    try {
        const [events] = await db.query(`
            SELECT e.*, c.category_name, u.full_name as creator_name
            FROM events e
            LEFT JOIN categories c ON e.category_id = c.category_id
            LEFT JOIN users u ON e.created_by = u.user_id
            WHERE e.category_id = ?
            ORDER BY e.event_date DESC
        `, [req.params.categoryId]);

        res.json(events);
    } catch (error) {
        console.error('Get events by category error:', error);
        res.status(500).json({ error: 'Failed to fetch events' });
    }
});

// Create new event
router.post('/', async (req, res) => {
    try {
        const { title, description, eventDate, location, categoryId, capacity, bannerImg, createdBy } = req.body;

        const [result] = await db.query(
            'INSERT INTO events (title, description, event_date, location, category_id, capacity, available_seats, banner_img, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [title, description, eventDate, location, categoryId, capacity, capacity, bannerImg, createdBy]
        );

        const [newEvent] = await db.query('SELECT * FROM events WHERE event_id = ?', [result.insertId]);
        res.status(201).json(newEvent[0]);
    } catch (error) {
        console.error('Create event error:', error);
        res.status(500).json({ error: 'Failed to create event' });
    }
});

// Update event
router.put('/:id', async (req, res) => {
    try {
        const { title, description, eventDate, location, categoryId, capacity, bannerImg } = req.body;

        await db.query(
            'UPDATE events SET title = ?, description = ?, event_date = ?, location = ?, category_id = ?, capacity = ?, banner_img = ? WHERE event_id = ?',
            [title, description, eventDate, location, categoryId, capacity, bannerImg, req.params.id]
        );

        const [updatedEvent] = await db.query('SELECT * FROM events WHERE event_id = ?', [req.params.id]);
        res.json(updatedEvent[0]);
    } catch (error) {
        console.error('Update event error:', error);
        res.status(500).json({ error: 'Failed to update event' });
    }
});

// Delete event
router.delete('/:id', async (req, res) => {
    try {
        await db.query('DELETE FROM events WHERE event_id = ?', [req.params.id]);
        res.json({ message: 'Event deleted successfully' });
    } catch (error) {
        console.error('Delete event error:', error);
        res.status(500).json({ error: 'Failed to delete event' });
    }
});

module.exports = router;
