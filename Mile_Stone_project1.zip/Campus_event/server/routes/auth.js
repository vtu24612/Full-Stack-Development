const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../config/database');

// Register new user
router.post('/register', async (req, res) => {
    try {
        const { fullName, email, studentId, password, role } = req.body;

        // Check if email already exists
        const [existingUsers] = await db.query(
            'SELECT * FROM users WHERE email = ?',
            [email]
        );

        if (existingUsers.length > 0) {
            return res.status(400).json({ error: 'Email already registered' });
        }

        // Check if student ID already exists
        const [existingStudents] = await db.query(
            'SELECT * FROM users WHERE student_id = ?',
            [studentId]
        );

        if (existingStudents.length > 0) {
            return res.status(400).json({ error: 'Student ID already registered' });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Insert new user
        const [result] = await db.query(
            'INSERT INTO users (full_name, email, student_id, password_hash, role) VALUES (?, ?, ?, ?, ?)',
            [fullName, email, studentId, hashedPassword, role || 'student']
        );

        res.status(201).json({
            userId: result.insertId,
            fullName,
            email,
            role: role || 'student',
            message: 'Registration successful'
        });
    } catch (error) {
        console.error('Register error:', error);
        res.status(500).json({ error: 'Registration failed' });
    }
});

// Login user
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Find user by email
        const [users] = await db.query(
            'SELECT * FROM users WHERE email = ?',
            [email]
        );

        if (users.length === 0) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const user = users[0];

        // Verify password
        const isValidPassword = await bcrypt.compare(password, user.password_hash);

        if (!isValidPassword) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        res.json({
            userId: user.user_id,
            fullName: user.full_name,
            email: user.email,
            studentId: user.student_id,
            role: user.role,
            message: 'Login successful'
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Login failed' });
    }
});

// Get user by ID
router.get('/user/:id', async (req, res) => {
    try {
        const [users] = await db.query(
            'SELECT user_id, full_name, email, student_id, role, created_at FROM users WHERE user_id = ?',
            [req.params.id]
        );

        if (users.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json(users[0]);
    } catch (error) {
        console.error('Get user error:', error);
        res.status(500).json({ error: 'Failed to fetch user' });
    }
});

module.exports = router;
