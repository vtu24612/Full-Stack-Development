const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Get all categories
router.get('/', async (req, res) => {
    try {
        const [categories] = await db.query('SELECT * FROM categories ORDER BY category_name');
        res.json(categories);
    } catch (error) {
        console.error('Get categories error:', error);
        res.status(500).json({ error: 'Failed to fetch categories' });
    }
});

// Get category by ID
router.get('/:id', async (req, res) => {
    try {
        const [categories] = await db.query('SELECT * FROM categories WHERE category_id = ?', [req.params.id]);
        
        if (categories.length === 0) {
            return res.status(404).json({ error: 'Category not found' });
        }

        res.json(categories[0]);
    } catch (error) {
        console.error('Get category error:', error);
        res.status(500).json({ error: 'Failed to fetch category' });
    }
});

// Create new category
router.post('/', async (req, res) => {
    try {
        const { categoryName } = req.body;

        // Check if category already exists
        const [existing] = await db.query('SELECT * FROM categories WHERE category_name = ?', [categoryName]);
        
        if (existing.length > 0) {
            return res.status(400).json({ error: 'Category already exists' });
        }

        const [result] = await db.query('INSERT INTO categories (category_name) VALUES (?)', [categoryName]);
        
        const [newCategory] = await db.query('SELECT * FROM categories WHERE category_id = ?', [result.insertId]);
        res.status(201).json(newCategory[0]);
    } catch (error) {
        console.error('Create category error:', error);
        res.status(500).json({ error: 'Failed to create category' });
    }
});

module.exports = router;
