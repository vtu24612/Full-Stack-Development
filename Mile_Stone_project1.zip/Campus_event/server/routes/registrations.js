const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Register for event
router.post('/', async (req, res) => {
    const connection = await db.getConnection();
    
    try {
        await connection.beginTransaction();

        const { userId, eventId } = req.body;

        // Check if already registered
        const [existing] = await connection.query(
            'SELECT * FROM registrations WHERE user_id = ? AND event_id = ?',
            [userId, eventId]
        );

        if (existing.length > 0) {
            await connection.rollback();
            return res.status(400).json({ error: 'Already registered for this event' });
        }

        // Check available seats
        const [events] = await connection.query(
            'SELECT available_seats FROM events WHERE event_id = ?',
            [eventId]
        );

        if (events.length === 0) {
            await connection.rollback();
            return res.status(404).json({ error: 'Event not found' });
        }

        if (events[0].available_seats <= 0) {
            await connection.rollback();
            return res.status(400).json({ error: 'No seats available' });
        }

        // Create registration
        const [result] = await connection.query(
            'INSERT INTO registrations (user_id, event_id, status) VALUES (?, ?, ?)',
            [userId, eventId, 'confirmed']
        );

        // Decrement available seats
        await connection.query(
            'UPDATE events SET available_seats = available_seats - 1 WHERE event_id = ?',
            [eventId]
        );

        await connection.commit();

        const [newRegistration] = await db.query(`
            SELECT r.*, e.title as event_title, e.event_date, e.location
            FROM registrations r
            JOIN events e ON r.event_id = e.event_id
            WHERE r.registration_id = ?
        `, [result.insertId]);

        res.status(201).json(newRegistration[0]);
    } catch (error) {
        await connection.rollback();
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Registration failed' });
    } finally {
        connection.release();
    }
});

// Get user's registrations
router.get('/user/:userId', async (req, res) => {
    try {
        const [registrations] = await db.query(`
            SELECT r.*, e.title, e.description, e.event_date, e.location, 
                   e.banner_img, c.category_name
            FROM registrations r
            JOIN events e ON r.event_id = e.event_id
            LEFT JOIN categories c ON e.category_id = c.category_id
            WHERE r.user_id = ?
            ORDER BY e.event_date DESC
        `, [req.params.userId]);

        res.json(registrations);
    } catch (error) {
        console.error('Get user registrations error:', error);
        res.status(500).json({ error: 'Failed to fetch registrations' });
    }
});

// Get event's registrations
router.get('/event/:eventId', async (req, res) => {
    try {
        const [registrations] = await db.query(`
            SELECT r.*, u.full_name, u.email, u.student_id
            FROM registrations r
            JOIN users u ON r.user_id = u.user_id
            WHERE r.event_id = ?
            ORDER BY r.registration_date DESC
        `, [req.params.eventId]);

        res.json(registrations);
    } catch (error) {
        console.error('Get event registrations error:', error);
        res.status(500).json({ error: 'Failed to fetch registrations' });
    }
});

// Cancel registration
router.delete('/:id', async (req, res) => {
    const connection = await db.getConnection();
    
    try {
        await connection.beginTransaction();

        // Get registration details
        const [registrations] = await connection.query(
            'SELECT * FROM registrations WHERE registration_id = ?',
            [req.params.id]
        );

        if (registrations.length === 0) {
            await connection.rollback();
            return res.status(404).json({ error: 'Registration not found' });
        }

        const registration = registrations[0];

        // Delete registration
        await connection.query('DELETE FROM registrations WHERE registration_id = ?', [req.params.id]);

        // Increment available seats
        await connection.query(
            'UPDATE events SET available_seats = available_seats + 1 WHERE event_id = ?',
            [registration.event_id]
        );

        await connection.commit();

        res.json({ message: 'Registration cancelled successfully' });
    } catch (error) {
        await connection.rollback();
        console.error('Cancel registration error:', error);
        res.status(500).json({ error: 'Failed to cancel registration' });
    } finally {
        connection.release();
    }
});

module.exports = router;
